#!/bin/sh

./lib/ant/bin/ant $@
